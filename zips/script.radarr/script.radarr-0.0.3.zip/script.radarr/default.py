from resources.lib.main import CreateRadarrMenu
import sys

CreateRadarrMenu(sys.argv)
