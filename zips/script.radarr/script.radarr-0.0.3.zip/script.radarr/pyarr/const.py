"""PyArr Constants"""
from logging import Logger, getLogger

LOGGER: Logger = getLogger(__package__)

PAGE = 1
PAGE_SIZE = 10
