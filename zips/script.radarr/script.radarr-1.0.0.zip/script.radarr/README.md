Uses: https://github.com/totaldebug/pyarr
